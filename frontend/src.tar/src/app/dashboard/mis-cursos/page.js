import MisCursosView from "@/components/dashboard/studentProfile/MisCursosView";
export default function CursosPage() {
  return <MisCursosView />;
}