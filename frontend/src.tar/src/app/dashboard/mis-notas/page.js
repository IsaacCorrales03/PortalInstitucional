import MisNotasView from "@/components/dashboard/studentProfile/MisNotasView";
export default function MisNotas() {
    return <MisNotasView />;
}