import MiAsistenciaView from "@/components/dashboard/studentProfile/MiAsistenciaView";
export default function asistenciaPage() {
    return <MiAsistenciaView />;
}