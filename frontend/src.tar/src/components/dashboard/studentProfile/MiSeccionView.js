"use client";

import { useState, useEffect } from "react";
import { getMySection } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

const SHIFT_LABELS = { diurna: "Diurna", nocturna: "Nocturna" };

function InitialsAvatar({ name, size = 40 }) {
  const initials =
    name
      ?.split(" ")
      .slice(0, 2)
      .map((w) => w[0])
      .join("")
      .toUpperCase() ?? "?";
  return (
    <div
      className="db-initials-avatar"
      style={{ width: size, height: size, fontSize: size * 0.36 }}
    >
      {initials}
    </div>
  );
}

export default function MiSeccionView() {
  const [section, setSection] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getMySection()
      .then(setSection)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="db-view">
      <SectionHeader
        title="Mi sección"
        subtitle="Información de tu grupo, profesor guía y materias"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : !section ? (
        <InlineAlert type="info">No hay información de sección disponible.</InlineAlert>
      ) : (
        <>
          {/* ── Hero de sección ── */}
          <div className="db-section-hero">
            <div className="db-section-hero-left">
              <div className="db-section-hero-badge">
                {section.section_name}
              </div>
              <div className="db-section-hero-meta">
                {section.shift && (
                  <span className="db-badge badge--blue">
                    {SHIFT_LABELS[section.shift] ?? section.shift}
                  </span>
                )}
                {section.academic_year && (
                  <span className="db-badge badge--gray">{section.academic_year}</span>
                )}
              </div>
              {section.specialty_name && (
                <p className="db-section-hero-specialty">{section.specialty_name}</p>
              )}
            </div>

            {/* ── Profesor guía ── */}
            {section.guide_professor_name && (
              <div className="db-guide-professor-card">
                <div className="db-guide-professor-label">Profesor guía</div>
                <div className="db-guide-professor-body">
                  <InitialsAvatar name={section.guide_professor_name} size={44} />
                  <div className="db-guide-professor-name">
                    {section.guide_professor_name}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* ── Cursos y profesores ── */}
          {section.courses?.length > 0 && (
            <div className="db-profile-section">
              <div className="db-profile-section-header">
                <h2 className="db-profile-section-title">Materias</h2>
                <span className="db-badge badge--gray">
                  {section.courses.length} cursos
                </span>
              </div>
              <div className="db-professor-grid">
                {section.courses.map((c, i) => (
                  <div key={i} className="db-professor-card">
                    <InitialsAvatar name={c.professor_name} size={40} />
                    <div className="db-professor-card-info">
                      <span className="db-professor-card-subject">{c.course_name}</span>
                      <span className="db-professor-card-name">
                        {c.professor_name ?? "Sin docente"}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}