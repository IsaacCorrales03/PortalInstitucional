"use client";

import { useState, useEffect } from "react";
import { getMyAnnouncements } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

function fmtRelative(dateStr) {
  if (!dateStr) return "—";
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / 86400000);
  if (days === 0) return "Hoy";
  if (days === 1) return "Ayer";
  if (days < 7) return `Hace ${days} días`;
  return new Date(dateStr).toLocaleDateString("es-CR", {
    day: "2-digit", month: "short", year: "numeric",
  });
}

const TARGET_BADGE = {
  estudiante:    "badge--blue",
  docente:       "badge--purple",
  administrativo:"badge--teal",
};

export default function AnnouncementView() {
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    getMyAnnouncements()
      .then(setAnnouncements)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="db-view">
      <SectionHeader
        title="Avisos"
        subtitle="Comunicados institucionales dirigidos a ti"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : announcements.length === 0 ? (
        <div className="db-empty">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
          </svg>
          <p>No hay avisos publicados en este momento.</p>
        </div>
      ) : (
        <div className="db-announcement-list">
          {announcements.map((a) => {
            const isOpen = expanded === a.id;
            return (
              <div
                key={a.id}
                className={`db-announcement-item ${isOpen ? "db-announcement-item--open" : ""}`}
              >
                <button
                  className="db-announcement-header"
                  onClick={() => setExpanded(isOpen ? null : a.id)}
                >
                  <div className="db-announcement-icon">
                    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" width={18} height={18}>
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                        d="M11 5.882V19.24a1.76 1.76 0 01-3.417.592l-2.147-6.15M18 13a3 3 0 100-6M5.436 13.683A4.001 4.001 0 017 6h1.832c4.1 0 7.625-1.234 9.168-3v14c-1.543-1.766-5.067-3-9.168-3H7a3.988 3.988 0 01-1.564-.317z" />
                    </svg>
                  </div>

                  <div className="db-announcement-title-wrap">
                    <span className="db-announcement-title">{a.title}</span>
                    <div className="db-announcement-meta">
                      <span style={{ fontSize: 12, color: "var(--db-text-muted)" }}>
                        {fmtRelative(a.published_at)}
                      </span>
                      {a.target_role && (
                        <span className={`db-badge ${TARGET_BADGE[a.target_role] ?? "badge--gray"}`}>
                          {a.target_role}
                        </span>
                      )}
                      {a.target_section_name && (
                        <span className="db-badge badge--gray">
                          Sección {a.target_section_name}
                        </span>
                      )}
                    </div>
                  </div>

                  <svg
                    className="db-announcement-chevron"
                    fill="none" viewBox="0 0 24 24" stroke="currentColor"
                    width={16} height={16}
                    style={{ transform: isOpen ? "rotate(180deg)" : "rotate(0deg)", transition: "transform 0.2s" }}
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                      d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {isOpen && (
                  <div className="db-announcement-body">
                    <p className="db-announcement-content">{a.content}</p>
                    {a.created_by_name && (
                      <div className="db-announcement-author">
                        Publicado por {a.created_by_name}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
