"use client";

import { useState, useEffect } from "react";
import { getMyScholarships } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

const TYPE_LABELS = {
  transporte: "Transporte",
  alimentacion: "Alimentación",
};

const STATUS_BADGE = {
  activa:     "badge--green",
  suspendida: "badge--orange",
  finalizada: "badge--gray",
};

const TYPE_ICONS = {
  transporte: (
    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" width={24} height={24}>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
        d="M8 7h8m-8 5h8m-4 5v-5m-7 9h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
    </svg>
  ),
  alimentacion: (
    <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" width={24} height={24}>
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
        d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />
    </svg>
  ),
};

function fmt(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("es-CR", {
    day: "2-digit", month: "short", year: "numeric",
  });
}

export default function ScholarshipView() {
  const [scholarships, setScholarships] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getMyScholarships()
      .then(setScholarships)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const active = scholarships.filter((s) => s.status === "activa");
  const inactive = scholarships.filter((s) => s.status !== "activa");

  return (
    <div className="db-view">
      <SectionHeader
        title="Mis becas"
        subtitle="Beneficios activos e historial de becas otorgadas"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : scholarships.length === 0 ? (
        <div className="db-empty">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
          </svg>
          <p>No tienes becas registradas.</p>
        </div>
      ) : (
        <>
          {active.length > 0 && (
            <div className="db-profile-section">
              <div className="db-profile-section-header">
                <h2 className="db-profile-section-title">Becas activas</h2>
                <span className="db-badge badge--green">{active.length} activa{active.length !== 1 ? "s" : ""}</span>
              </div>
              <div className="db-scholarship-grid">
                {active.map((s) => (
                  <ScholarshipCard key={s.id} scholarship={s} />
                ))}
              </div>
            </div>
          )}

          {inactive.length > 0 && (
            <div className="db-profile-section">
              <div className="db-profile-section-header">
                <h2 className="db-profile-section-title">Historial</h2>
              </div>
              <div className="db-table-wrap">
                <table className="db-table">
                  <thead>
                    <tr>
                      <th>Tipo</th>
                      <th>Inicio</th>
                      <th>Fin</th>
                      <th>Estado</th>
                    </tr>
                  </thead>
                  <tbody>
                    {inactive.map((s) => (
                      <tr key={s.id}>
                        <td>{TYPE_LABELS[s.type] ?? s.type}</td>
                        <td>{fmt(s.start_date)}</td>
                        <td>{fmt(s.end_date)}</td>
                        <td>
                          <span className={`db-badge ${STATUS_BADGE[s.status] ?? "badge--gray"}`}>
                            {s.status}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function ScholarshipCard({ scholarship: s }) {
  return (
    <div className="db-scholarship-card">
      <div className="db-scholarship-card-icon">
        {TYPE_ICONS[s.type] ?? TYPE_ICONS.transporte}
      </div>
      <div className="db-scholarship-card-body">
        <div className="db-scholarship-card-type">
          {TYPE_LABELS[s.type] ?? s.type}
        </div>
        <div className="db-scholarship-card-dates">
          Desde {fmt(s.start_date)}
          {s.end_date ? ` hasta ${fmt(s.end_date)}` : " · Sin fecha de vencimiento"}
        </div>
        {s.notes && (
          <div className="db-scholarship-card-notes">{s.notes}</div>
        )}
      </div>
      <span className={`db-badge ${STATUS_BADGE[s.status] ?? "badge--gray"}`}>
        {s.status}
      </span>
    </div>
  );
}
