"use client";

import { useState, useEffect } from "react";
import { getMyGradeReports } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

const STATUS_BADGE = {
  aprobado:  "badge--green",
  reprobado: "badge--red",
  pendiente: "badge--orange",
};

function fmt(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("es-CR", {
    day: "2-digit", month: "short", year: "numeric",
  });
}

function gradeColor(grade) {
  if (grade === null || grade === undefined) return "var(--db-text-muted)";
  if (grade >= 70) return "#16A34A";
  if (grade >= 60) return "#D97706";
  return "#DC2626";
}

export default function GradeReportView() {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    getMyGradeReports()
      .then((data) => {
        setReports(data);
        if (data.length > 0) setSelected(data[0].period_id);
      })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const periods = [...new Map(reports.map((r) => [r.period_id, r.period_name])).entries()];
  const filtered = reports.filter((r) => r.period_id === selected);

  return (
    <div className="db-view">
      <SectionHeader
        title="Mis calificaciones"
        subtitle="Boletines por período académico"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : reports.length === 0 ? (
        <div className="db-empty">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <p>No hay boletines disponibles.</p>
        </div>
      ) : (
        <>
          {/* ── Selector de período ── */}
          {periods.length > 1 && (
            <div className="db-tabs">
              {periods.map(([id, name]) => (
                <button
                  key={id}
                  className={`db-tab ${selected === id ? "db-tab--active" : ""}`}
                  onClick={() => setSelected(id)}
                >
                  {name}
                </button>
              ))}
            </div>
          )}

          {/* ── Boletines del período ── */}
          {filtered.map((r) => (
            <div key={r.id} className="db-grade-report-card">
              <div className="db-grade-report-header">
                <div>
                  <div className="db-grade-report-section">{r.section_name}</div>
                  <div className="db-grade-report-period">{r.period_name}</div>
                </div>
                <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 6 }}>
                  <span
                    className="db-grade-report-score"
                    style={{ color: gradeColor(r.final_grade) }}
                  >
                    {r.final_grade !== null ? Number(r.final_grade).toFixed(1) : "—"}
                  </span>
                  <span className={`db-badge ${STATUS_BADGE[r.status] ?? "badge--gray"}`}>
                    {r.status}
                  </span>
                </div>
              </div>

              {/* Evaluaciones individuales */}
              {r.evaluations?.length > 0 && (
                <div className="db-grade-report-body">
                  <table className="db-table">
                    <thead>
                      <tr>
                        <th>Evaluación</th>
                        <th>Peso</th>
                        <th>Vence</th>
                        <th>Nota</th>
                      </tr>
                    </thead>
                    <tbody>
                      {r.evaluations.map((ev) => (
                        <tr key={ev.evaluation_id}>
                          <td>{ev.title}</td>
                          <td>
                            {ev.weight_percent !== null
                              ? `${ev.weight_percent}%`
                              : "—"}
                          </td>
                          <td style={{ color: "var(--db-text-muted)", fontSize: 13 }}>
                            {fmt(ev.due_date)}
                          </td>
                          <td>
                            <span
                              style={{
                                fontWeight: 700,
                                color: gradeColor(ev.score),
                              }}
                            >
                              {ev.score !== null ? Number(ev.score).toFixed(1) : "Pendiente"}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}

              {r.generated_at && (
                <div className="db-grade-report-footer">
                  Generado el {fmt(r.generated_at)}
                </div>
              )}
            </div>
          ))}
        </>
      )}
    </div>
  );
}
