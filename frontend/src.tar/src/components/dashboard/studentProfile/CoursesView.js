"use client";

import { useState, useEffect } from "react";
import { getMyCourses } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

export default function CoursesView() {
  const [courses, setCourses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getMyCourses()
      .then(setCourses)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="db-view">
      <SectionHeader
        title="Mis cursos"
        subtitle="Materias asignadas a tu sección este año"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : courses.length === 0 ? (
        <div className="db-empty">
          <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
              d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
          </svg>
          <p>No hay cursos registrados para tu sección.</p>
        </div>
      ) : (
        <div className="db-course-grid">
          {courses.map((c) => (
            <div key={c.course_id} className="db-course-card">
              <div className="db-course-card-header">
                <div className="db-course-icon">
                  <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" />
                  </svg>
                </div>
                <div className="db-course-card-name">{c.course_name}</div>
              </div>
              {c.description && (
                <p className="db-course-card-desc">{c.description}</p>
              )}
              <div className="db-course-card-footer">
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor" width={13} height={13}>
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                    d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <span>{c.professor_name ?? "Sin docente asignado"}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
