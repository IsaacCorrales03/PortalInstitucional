"use client";

import { useState, useEffect } from "react";
import { getMyAttendance } from "@/lib/api";
import { SectionHeader, InlineAlert, Spinner } from "@/components/dashboard/ui";

function fmt(dateStr) {
  if (!dateStr) return "—";
  return new Date(dateStr).toLocaleDateString("es-CR", {
    weekday: "short", day: "2-digit", month: "short",
  });
}

function AttendanceDot({ present, late }) {
  if (late) return <span className="db-att-dot db-att-dot--late" title="Tardía" />;
  if (present) return <span className="db-att-dot db-att-dot--present" title="Presente" />;
  return <span className="db-att-dot db-att-dot--absent" title="Ausente" />;
}

export default function AttendanceView() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    getMyAttendance()
      .then(setData)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const summary = data?.summary;
  const records = data?.records ?? [];

  const pct = summary?.total
    ? Math.round((summary.present / summary.total) * 100)
    : null;

  return (
    <div className="db-view">
      <SectionHeader
        title="Mi asistencia"
        subtitle="Registro de presencias, ausencias y tardías"
      />

      {loading ? (
        <div className="db-loading">
          <Spinner />
        </div>
      ) : error ? (
        <InlineAlert type="error">{error}</InlineAlert>
      ) : !data ? (
        <InlineAlert type="info">No hay registros de asistencia.</InlineAlert>
      ) : (
        <>
          {/* ── Resumen numérico ── */}
          <div className="db-overview-grid">
            <StatCard
              label="Total de clases"
              value={summary?.total ?? 0}
              color="rgba(37,99,235,0.10)"
              iconColor="#2563EB"
              icon={
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
              }
            />
            <StatCard
              label="Presencias"
              value={summary?.present ?? 0}
              color="rgba(22,163,74,0.10)"
              iconColor="#16A34A"
              icon={
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />
            <StatCard
              label="Ausencias"
              value={summary?.absent ?? 0}
              color="rgba(220,38,38,0.10)"
              iconColor="#DC2626"
              icon={
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />
            <StatCard
              label="Tardías"
              value={summary?.late ?? 0}
              color="rgba(217,119,6,0.10)"
              iconColor="#D97706"
              icon={
                <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              }
            />
          </div>

          {/* ── Barra de porcentaje ── */}
          {pct !== null && (
            <div className="db-profile-section">
              <div className="db-profile-section-header">
                <h2 className="db-profile-section-title">Porcentaje de asistencia</h2>
                <span
                  className={`db-badge ${
                    pct >= 90 ? "badge--green" : pct >= 75 ? "badge--orange" : "badge--red"
                  }`}
                >
                  {pct}%
                </span>
              </div>
              <div className="db-att-bar-track">
                <div
                  className="db-att-bar-fill"
                  style={{
                    width: `${pct}%`,
                    background:
                      pct >= 90
                        ? "#16A34A"
                        : pct >= 75
                        ? "#D97706"
                        : "#DC2626",
                  }}
                />
              </div>
              {pct < 75 && (
                <InlineAlert type="warning">
                  Tu porcentaje de asistencia está por debajo del mínimo requerido (75%).
                </InlineAlert>
              )}
            </div>
          )}

          {/* ── Registro detallado ── */}
          {records.length > 0 && (
            <div className="db-profile-section">
              <div className="db-profile-section-header">
                <h2 className="db-profile-section-title">Registro</h2>
              </div>
              <div className="db-table-wrap">
                <table className="db-table">
                  <thead>
                    <tr>
                      <th>Fecha</th>
                      <th>Estado</th>
                      <th>Justificación</th>
                    </tr>
                  </thead>
                  <tbody>
                    {records.map((r) => (
                      <tr key={r.id}>
                        <td>{fmt(r.date)}</td>
                        <td>
                          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                            <AttendanceDot present={r.present} late={r.late} />
                            <span
                              className={`db-badge ${
                                r.late
                                  ? "badge--orange"
                                  : r.present
                                  ? "badge--green"
                                  : "badge--red"
                              }`}
                            >
                              {r.late ? "Tardía" : r.present ? "Presente" : "Ausente"}
                            </span>
                          </div>
                        </td>
                        <td style={{ color: "var(--db-text-muted)", fontSize: 13 }}>
                          {r.justification ?? "—"}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, color, iconColor, icon }) {
  return (
    <div className="db-stat-card">
      <div className="db-stat-icon" style={{ background: color, color: iconColor }}>
        {icon}
      </div>
      <div className="db-stat-value">{value}</div>
      <div className="db-stat-label">{label}</div>
    </div>
  );
}
